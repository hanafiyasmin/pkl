function validateForm() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const repeatPassword = document.getElementById('repeat-password').value.trim();
    const messageDiv = document.getElementById('message');

    messageDiv.textContent = ''; 

    if (!username) {
        messageDiv.textContent = 'Username harus diisi!';
        return;
    }
    if (!password) {
        messageDiv.textContent = 'Password harus diisi!';
        return;
    }
    if (!repeatPassword) {
        messageDiv.textContent = 'Ulangi password harus diisi!';
        return;
    }

    if (password !== repeatPassword) {
        messageDiv.textContent = 'Password dan Ulangi Password tidak cocok!';
        return;
    }

    if (password.length < 8) {
        messageDiv.textContent = 'Password harus minimal 8 karakter!';
        return;
    }

    const validUsername = 'admin'; 
    const validPassword = 'admin123';

    if (username !== validUsername || password !== validPassword) {
        messageDiv.textContent = 'Username atau Password tidak sesuai dengan ketentuan!';
        return;
    }

    alert('Login berhasil! Selamat datang!');
    window.location.href = 'halaman-berikutnya.html'; 
}

function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    field.type = field.type === 'password' ? 'text' : 'password';
}
